#include "contact"
#include "address.h"
#include <gtest/gtest.h>
namespace {

class AddressTest : public ::testing::Test {

protected:
  void SetUp() { 
    contacts.addContact("saumya","shekhar","95765856","95473245");
    contacts.addContact("vaishu","vj","57683687","586785");
    contacts.addContact("johnson","jkon","585767","968796");
    contacts.addContact("kats","kaif","8697894758","867857054");

  }
 
};

TEST_F(AddressTest, AddContactTest) 
{
  contacts.addContact("martina", "joseph","85587687",,"89987021");
  EXPECT_NE(NULL, books.findContactByprim("855876871"));
  EXPECT_EQ("855876871", books.getprimno());
}
TEST_F(AddressTest, RemoveContactTest)
 {
  accounts.removeContact();
  EXPECT_EQ(NULL, accounts.findBookById("22585767"));
  EXPECT_EQ(NULL, accounts.getprimno("22585767"));
}





} // namespace*/
