#include "book.h"
#include"library.h"
#include <gtest/gtest.h>
namespace 
{

class LibraryTest : public ::testing::Test 
{

    protected:
    void SetUp() { 
{
        libr.addBook( 101,"c++","saumya","mc hill",300,200 );
        libr.addBook( 102,"python","nikitha","story",600,500 );
        libr.addBook( 103,"Webdev","Johnson","sunstar",400,220);
    }
    void TearDown() {
    }
    Library libr;
};
TEST_F(LibraryTest,CountAccounts) 
{
  EXPECT_EQ(3,libr.countAll());
}

TEST_F(LibraryTest,AddBook) 
{
  libr.addBook( 104,"Linux","shwetha","sanvi",400,300 );
  EXPECT_EQ(4,libr.countAll());
  Book *ptr=libr.findBookById( 104 );
  EXPECT_NE(nullptr, ptr);
  EXPECT_EQ(104, ptr->getId());
  EXPECT_EQ(600, ptr->getPrice());
}
TEST_F(LibraryTest,RemoveBook) 
{
  libr.removeBook( 102 );
  EXPECT_EQ(2,libr.countAll());
  Book *ptr=libr.findBookById( 102);
  EXPECT_EQ(nullptr, ptr);
}
}


