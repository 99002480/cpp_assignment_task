#include "account.h"
#include "banking.h"
#include <gtest/gtest.h>
namespace {

class BankingTest : public ::testing::Test {

protected:
  void SetUp() { 
    accounts.addAccount(101, "Saumya",45.23,"9845055345");
    accounts.addAccount(102, "shifali",33.23,"4576589953");
    accounts.addAccount(103, "hellen",67.55,"8845675445");
    accounts.addAccount(104, "Sahana",46.43,"9576832132");
  }
 
};

TEST_F(BankingTest, AddAccountTest) {
  accounts.addAccount(105, "John", "9845012350", 100);
  EXPECT_NE(NULL, accounts.findCustomerById(105));
  EXPECT_EQ(105, accounts.getCustomerId());
}
TEST_F(BankingTest, RemoveAccountTest) {
  accounts.removeAccount(105);
  EXPECT_EQ(NULL, accounts.findCustomerById(105));
  EXPECT_EQ(NULL, accounts.getCustomerId());
}

TEST_F(BankingTest, FindByNameTest) 
{
  Account *ptr = accounts.findCustomerByName("Sahana");
  EXPECT_STREQ("Sahana", ptr->getName().c_str());
  EXPECT_EQ(104, ptr->getCustomerId());
}

} 
